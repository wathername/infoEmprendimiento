<footer>
    <div class="pull-right">
        Info-Emprendimiento Unerg Ais
    </div>
    <div class="clearfix"></div>
</footer>