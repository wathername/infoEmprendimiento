<div class="sidebar-footer hidden-small">

    <a data-toggle="tooltip" data-placement="top" title="Salir" href="<?php echo e(url('/logout')); ?>"
       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
        <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
    </a>

    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>
</div>