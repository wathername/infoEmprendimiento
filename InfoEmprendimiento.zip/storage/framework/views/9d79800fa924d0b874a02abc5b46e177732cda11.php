<div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
    <label for="user_id" class="col-md-4 control-label"><?php echo e('User Id'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="user_id" type="number" id="user_id" value="<?php echo e(isset($academicdatum->user_id) ? $academicdatum->user_id : ''); ?>" required>
        <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('period_id') ? 'has-error' : ''); ?>">
    <label for="period_id" class="col-md-4 control-label"><?php echo e('Period Id'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="period_id" type="number" id="period_id" value="<?php echo e(isset($academicdatum->period_id) ? $academicdatum->period_id : ''); ?>" required>
        <?php echo $errors->first('period_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <input class="btn btn-primary" type="submit" value="<?php echo e(isset($submitButtonText) ? $submitButtonText : 'Create'); ?>">
    </div>
</div>
