<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="page-title">
            <div class="title_left">
                <hr>
                <h2>Registro Datos Academicos</h2>
            </div>
        </div>
        <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <a href="<?php echo e(url('/home')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />
                        <div class="title text-center">
                            <h2>Ingrese Los Datos Solicitados</h2>
                            <hr>
                        </div>
                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(url('/academic-data/')); ?>" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
                            <?php echo e(method_field('POST')); ?>

                            <?php echo e(csrf_field()); ?>


                            <div class="form-group <?php echo e($errors->has('period_id') ? 'has-error' : ''); ?>">
                                <label for="period_id" class="col-md-4 control-label"><?php echo e('Periodo'); ?></label>
                                <div class="col-md-2">
                                    <?php echo Form::select('period_id', $period, old('period_id'), ['class' => 'form-control', 'required']); ?>

                                    <?php echo $errors->first('period_id', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="form-group <?php echo e($errors->has('matter_id') ? 'has-error' : ''); ?>">
                                <?php echo Form::label('matter_id', 'Materias', ['class' => 'col-md-4 control-label']); ?>

                                <div class="col-md-6 col-md-offset-0">
                                    <br>
                                    <?php $__currentLoopData = $matter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <input type="checkbox" name="matter_id[<?php echo e($matter->id); ?>]" id="matter_id" value="<?php echo e($matter->id); ?>">
                                            <span><?php echo e($matter->matter); ?></span>
                                            <?php echo $errors->first('matter_id', '<p class="help-block">:message</p>'); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-6 col-lg-offset-3">
                                    <hr>
                                </div>
                                <div class="col-md-offset-4 col-md-4">
                                    <button class="btn btn-success btn-block" type="submit"><i class="fa fa-plus-circle"> Guardar Datos Academicos</i></button>
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>