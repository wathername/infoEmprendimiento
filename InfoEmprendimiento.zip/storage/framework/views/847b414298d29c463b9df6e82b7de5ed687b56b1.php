<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="page-title">
            <div class="title_left">
                <hr>
                <h2>Registro de Informacion Personal</h2>
            </div>
        </div>
        <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <a href="<?php echo e(url('/admin/personal-information')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />
                        <div class="title text-center">
                            <h2>Ingrese Los Datos Solicitados</h2>
                            <div class="alert alert-warning alert-dismissable">
                                <h6> Estimado usuario una vez guardado las datos estos no podran ser modificados. Verifique la informacion antes de guardar los datos!.</h6>
                            </div>
                            <hr>
                        </div>
                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(url('/personal-information/')); ?>" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
                            <?php echo e(method_field('POST')); ?>

                            <?php echo e(csrf_field()); ?>


                            <div class="form-group <?php echo e($errors->has('type_id') ? 'has-error' : ''); ?>">
                                <label for="type_id" class="col-md-4 control-label"><?php echo e('Tipo C.I.'); ?></label>
                                <div class="col-md-1">
                                    <?php echo Form::select('type_id', $type, old('type_id'), ['class' => 'form-control', 'required']); ?>

                                    <?php echo $errors->first('type_id', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div><div class="form-group <?php echo e($errors->has('identification') ? 'has-error' : ''); ?>">
                                <label for="identification" class="col-md-4 control-label"><?php echo e('Cedula'); ?></label>
                                <div class="col-md-2">
                                    <input class="form-control" name="identification" type="text" id="identification" value="<?php echo e(isset($personalinformation->identification) ? $personalinformation->identification : ''); ?>" >
                                    <?php echo $errors->first('identification', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div><div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label"><?php echo e('Nombres'); ?></label>
                                <div class="col-md-4">
                                    <input class="form-control" name="name" type="text" id="name" value="<?php echo e(isset($personalinformation->name) ? $personalinformation->name : ''); ?>" required onkeyup="this.value=this.value.toUpperCase()" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='';}">
                                    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div><div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
                                <label for="last_name" class="col-md-4 control-label"><?php echo e('Apellidos'); ?></label>
                                <div class="col-md-4">
                                    <input class="form-control" name="last_name" type="text" id="last_name" value="<?php echo e(isset($personalinformation->last_name) ? $personalinformation->last_name : ''); ?>" required onkeyup="this.value=this.value.toUpperCase()" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='';}">
                                    <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div><div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                                <label for="phone" class="col-md-4 control-label"><?php echo e('Telefono'); ?></label>
                                <div class="col-md-2">
                                    <input class="form-control" name="phone" type="text" id="phone" value="<?php echo e(isset($personalinformation->phone) ? $personalinformation->phone : ''); ?>" required>
                                    <?php echo $errors->first('phone', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div><div class="form-group <?php echo e($errors->has('origin_city_id') ? 'has-error' : ''); ?>">
                                <label for="origin_city_id" class="col-md-4 control-label"><?php echo e('Ciudad Origen'); ?></label>
                                <div class="col-md-4">
                                    <?php echo Form::select('origin_city_id', $cities, old('origin_city_id'), ['class' => 'form-control', 'required']); ?>

                                    <?php echo $errors->first('origin_city_id', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div><div class="form-group <?php echo e($errors->has('recidency_city_id') ? 'has-error' : ''); ?>">
                                <label for="recidency_city_id" class="col-md-4 control-label"><?php echo e('Cuidad Recidencia'); ?></label>
                                <div class="col-md-4">
                                    <?php echo Form::select('recidency_city_id', $cities, old('recidency_city_id'), ['class' => 'form-control', 'required']); ?>

                                    <?php echo $errors->first('recidency_city_id', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div><div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                                <label for="address" class="col-md-4 control-label"><?php echo e('Direccion'); ?></label>
                                <div class="col-md-6">
                                    <textarea class="form-control" rows="5" name="address" type="textarea" id="address" value="<?php echo e(isset($personalinformation->address) ? $personalinformation->address : ''); ?>" required onkeyup="this.value=this.value.toUpperCase()" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='';}"><?php echo e(isset($personalinformation->address) ? $personalinformation->address : ''); ?></textarea>
                                    <?php echo $errors->first('address', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <?php if(\Illuminate\Support\Facades\Auth::user()->role_id == 1): ?>
                                <div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
                                    <label for="user_id" class="col-md-4 control-label"><?php echo e('User Id'); ?></label>
                                    <div class="col-md-1">
                                        <input class="form-control" name="user_id" type="number" id="user_id" value="<?php echo e(isset($personalinformation->user_id) ? $personalinformation->user_id : ''); ?>" readonly>
                                        <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

                                    </div>
                                </div>
                            <?php endif; ?>


                            <div class="form-group">
                                <div class="col-md-offset-4 col-md-4">
                                    <input class="btn btn-primary" type="submit" value="Guardar Datos Personales">
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>