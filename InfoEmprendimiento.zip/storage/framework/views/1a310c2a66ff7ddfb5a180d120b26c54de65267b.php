<?php $__env->startSection('content'); ?>
    <header id="head" class="secondary">
        <div class="container">
            <h1><?php echo e($post->title); ?></h1>
        </div>
    </header>
    <!-- container -->
    <hr>
    <section class="container">
        <div class="row">
            <!-- main content -->
            <section class="col-sm-8 maincontent">
                <p align="justify">
                    <img src="<?php echo e(asset($post->image)); ?>" alt="" class="img-rounded pull-right" width="300">
                    <?php echo e($post->content); ?>

                </p>

            </section>
            <!-- /main -->

            <!-- Sidebar -->
            <aside class="col-sm-4 sidebar sidebar-right">

                <div class="panel">
                    <h4>Nuevas Noticias</h4>
                    <ul class="list-unstyled list-spaces">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href=""><?php echo e($posts->title); ?></a><br>
                            <span class="small text-muted"><?php echo e($cadena =str_limit($posts->content, 80)); ?></span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            </aside>
            <!-- /Sidebar -->

        </div>
    </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>