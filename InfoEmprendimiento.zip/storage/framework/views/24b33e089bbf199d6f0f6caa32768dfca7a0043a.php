<ul class="messages">
    <hr>
    <?php if($personalinformation->statu_id != '4'): ?>
        <div>
            <a href="<?php echo e(route('personal-information')); ?>" class="btn btn-info btn-lg"><i class="fa fa-plus-circle"></i> Registar Datos Personales</a>
        </div>
    <?php else: ?>
        <div class="container">
            <div class="jumbotron">
                <div class="row">
                    <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">
                        <img src="https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png" alt="stack photo" class="img">
                    </div>
                    <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8">
                        <div class="container" style="border-bottom:1px solid black">
                            <h2><?php echo e($personalinformation->name); ?> <?php echo e($personalinformation->last_name); ?></h2>
                            <h3><?php echo e($personalinformation->type->type); ?><?php echo e($personalinformation->identification); ?></h3>
                        </div>
                        <hr>
                        <ul class="container details">
                            <li><p><span class="glyphicon glyphicon-earphone one" style="width:50px;"></span><?php echo e($personalinformation->phone); ?></p></li>
                            <li><p><span class="glyphicon glyphicon-envelope one" style="width:50px;"></span><?php echo e($personalinformation->user->email); ?></p></li>
                            <li><p><span class="glyphicon glyphicon-map-marker one" style="width:50px;"></span>Cuidad Origen - <?php echo e($personalinformation->origin_city->city); ?>, Estado <?php echo e($personalinformation->origin_city->state->state); ?></p></li>
                            <li><p><span class="glyphicon glyphicon-map-marker one" style="width:50px;"></span>Cuidad Recidencia - <?php echo e($personalinformation->recidency_city->city); ?>, Estado <?php echo e($personalinformation->origin_city->state->state); ?></p></li>
                            <li><p><span class="fa fa-location-arrow one" style="width:50px;"></span><?php echo e($personalinformation->address); ?></p></li>
                            <li><p><span class="fa fa-check-square one" style="width:50px;"></span>Estatus - <?php echo e($personalinformation->statu->statu); ?></p></li>
                        </ul>
                    </div>
                </div>
            </div>
    <?php endif; ?>
</ul>