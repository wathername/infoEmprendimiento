<div class="form-group <?php echo e($errors->has('user') ? 'has-error' : ''); ?>">
    <?php echo Form::label('user', 'Usuario', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('user', null, ['class' => 'form-control', 'required', 'onkeyup="this.value=this.value.toUpperCase()" onfocus="this.value="";" onblur="if (this.value == "") {this.value ="";}"']); ?>

        <?php echo $errors->first('user', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('email', null, ['class' => 'form-control', 'required']); ?>

        <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('profession') ? 'has-error' : ''); ?>">
    <?php echo Form::label('profession', 'Profesion', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('profession', $user->profession->profession, ['class' => 'form-control', 'required', 'readonly']); ?>

        <?php echo $errors->first('profession', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<?php if(\Illuminate\Support\Facades\Auth::user()->role_id == '1'): ?>
<div class="form-group <?php echo e($errors->has('role_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('role_id', 'Role', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('role_id', $role, old('category_service_id'), ['class' => 'form-control', 'required']); ?>

        <?php echo $errors->first('role_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('statu_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('statu_id', 'Statu', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('statu_id', $statu, old('category_service_id'), ['class' => 'form-control', 'required']); ?>

        <?php echo $errors->first('statu_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<?php endif; ?>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary btn-block btn-md']); ?>

    </div>
</div>
