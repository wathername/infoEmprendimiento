<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <label for="title" class="col-md-4 control-label"><?php echo e('Title'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="title" type="text" id="title" value="<?php echo e(isset($post->title) ? $post->title : ''); ?>" >
        <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
    <label for="content" class="col-md-4 control-label"><?php echo e('Content'); ?></label>
    <div class="col-md-6">
        <textarea class="form-control" rows="5" name="content" type="textarea" id="content" ><?php echo e(isset($post->content) ? $post->content : ''); ?></textarea>
        <?php echo $errors->first('content', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
    <label for="image" class="col-md-4 control-label"><?php echo e('Image'); ?></label>
    <div class="col-md-6">
        <input class="" name="image" type="file" id="image" value="<?php echo e(isset($post->image) ? $post->image : ''); ?>" >
        <?php echo $errors->first('image', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
    <label for="category_id" class="col-md-4 control-label"><?php echo e('Category Id'); ?></label>
    <div class="col-md-6">
        <?php echo Form::select('category_id', $categories, old('category_id'), ['class' => 'form-control']); ?>

        <?php echo $errors->first('category_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <input class="btn btn-primary" type="submit" value="<?php echo e(isset($submitButtonText) ? $submitButtonText : 'Create'); ?>">
    </div>
</div>
