<hr>
<div class="">
    <h2 class="text-center">Por favor ingresar los datos solicitados en cada materia seleccionada!</h2>
    <hr>
    <!-- Nav tabs --><div class="card">
        <ul class="nav nav-tabs" role="tablist">
            <?php $__currentLoopData = $academicData->matteracademicdatum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li role="presentation" class=""><a href="#<?php echo e($matter->matter->id); ?>" aria-controls="<?php echo e($matter->matter->id); ?>" role="tab" data-toggle="tab"><?php echo e($matter->matter->matter); ?></a></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane" id="1">
                <?php echo $__env->make('partials.pasantia', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="2">
                <?php echo $__env->make('partials.servicio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="3">
                <?php echo $__env->make('partials.proyecto_I', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="4">
                <?php echo $__env->make('partials.proyecto_II', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
</div>