    <?php if($company_data_pasantia_status == null): ?>
        <h1>Pasantias</h1>
        <div>
            <a href="<?php echo e(url('/company-data/Pasantias')); ?>" class="btn btn-info btn-lg"><i class="fa fa-plus-circle"></i> Registar Datos</a>
        </div>
    <?php else: ?>
        <div class="container">
            <div class="jumbotron">
                <div class="row">
                    <div class="container" style="border-bottom:1px solid black">
                        <h3>Datos Registrados de Pasantia</h3>
                    </div>
                    <hr>
                    <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8 col-lg-offset-2">
                        <ul class="container details">
                                    <div class="container text-right" style="border-bottom:1px solid black">
                                        <h4>Datos Empresariales</h4>
                                    </div>
                                    <hr>
                                <?php $__currentLoopData = $company_data_pasantia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company_data_pasantia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><p><span class="fa fa-building" style="width:50px;"></span><?php echo e($company_data_pasantia->name); ?></p></li>
                                    <li><p><span class="fa fa-info one" style="width:50px;"></span><?php echo e($company_data_pasantia->type); ?><?php echo e($company_data_pasantia->identification); ?> </p></li>
                                    <li><p><span class="glyphicon glyphicon-earphone one" style="width:50px;"></span><?php echo e($company_data_pasantia->phone); ?> </p></li>
                                    <li><p><span class="glyphicon glyphicon-envelope one" style="width:50px;"></span><?php echo e($company_data_pasantia->email); ?></p></li>
                                    <li><p><span class="fa fa-globe one" style="width:50px;"></span><?php echo e($company_data_pasantia->web_side); ?></p></li>
                                    <li><p><span class="fa fa-industry one" style="width:50px;"></span><?php echo e($company_data_pasantia->economic_activity); ?></p></li>
                                    <li><p><span class="glyphicon glyphicon-map-marker one" style="width:50px;"></span><?php echo e($company_data_pasantia->city); ?> - <?php echo e($company_data_pasantia->address); ?></p></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <hr>
                                    <div class="container text-right" style="border-bottom:1px solid black">
                                        <h4>Datos Tutor Empresarial</h4>
                                    </div>
                                    <hr>
                                    <?php $__currentLoopData = $tutor_data_pasantia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor_data_pasantia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><p><span class="glyphicon glyphicon-user one" style="width:50px;"></span><?php echo e($tutor_data_pasantia->name); ?> <?php echo e($tutor_data_pasantia->last_name); ?> </p></li>
                                        <li><p><span class="fa fa-info one" style="width:50px;"></span><?php echo e($tutor_data_pasantia->type); ?><?php echo e($tutor_data_pasantia->identification); ?> </p></li>
                                        <li><p><span class="glyphicon glyphicon-envelope one" style="width:50px;"></span><?php echo e($tutor_data_pasantia->email_tutor); ?></p></li>
                                        <li><p><span class="glyphicon glyphicon-earphone one" style="width:50px;"></span><?php echo e($tutor_data_pasantia->phone); ?> </p></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>